#===================                convert to basis        ======================
basis      <- function(x){
  break1   <- quantile(x,1/3)
  break2   <- quantile(x,2/3)
  return(cbind(x,x^2,x^3,pmax((x-break1)^3,0),pmax((x-break2)^3,0)))
}
  
g_f           <- function(x){ log(x/(1-x)) }
dg_f          <- function(x){ 1/(x*(1-x)) }  # the dg/du
gverse        <- function(x){1/(1+exp(-x))}

#===================                group scad              =======================

group_scad      <- function(xbasis,ydata,lambda,gamma=3.7){
  
  
  n             <- length(ydata)
  p             <- ncol(xbasis)
                  
  z             <- log(ydata/(1-ydata))
  lmz           <- lm(z~xbasis-1)
  beta0         <- lmz$coef
  e             <- lmz$residual
  mu            <- gverse(lmz$fit)
  sigma         <- var(e)/((n-p)*dg_f(mu)^2)
  phi0          <- sum(mu*(1-mu)/sigma-1)/n
  
  start         <- c(beta0,phi0)  # initial value
  
  
  beta<- function(h, y, x)
  {
    p           <- ncol(x)
    hx          <- x%*%h[1:p]
    mu          <- 1/(1+exp(-hx))
    phi         <- h[p+1]
    mu          <- ifelse(mu<=0.0001,0.0001,mu)
    y           <- ifelse(y>0.995,0.995,y)
    y           <- ifelse(y<0.002,0.002,y)
    loglik      <- lgamma(phi)-lgamma(mu*phi)-lgamma(phi-mu*phi)+mu*phi*log(y)+(phi-mu*phi)*log(1-y)-log(y)-log(1-y)
    
    pscad=function(x){
      
      if (x <= lambda)
          y  = lambda*x
      else if(x <= lambda*gamma)
          y  = (lambda*gamma*x-0.5*(x^2+lambda^2))/(gamma-1)
      else
          y = lambda^2*(gamma^2-1)/(2*(gamma-1))
      y
    }
    
    scad=0
    for (l in 1:(p/5)){
         g = 0
      for(k in 1:5){
         g = g+(h[5*(l-1)+k+1])^2
      }
      scad = scad+pscad(g^0.5)
    }
    
    -sum(loglik)+n*scad
    
    
  }
  
  betafit <- nlminb(start, beta, x = xbasis, y = ydata)
  
}

#===================                single scad             ===========================
single_scad     <- function(xdata,ydata,lambda,gamma=3.7){
  
  
  n             <- length(ydata)
  p             <- ncol(xdata)
  
  
  z             <- log(ydata/(1-ydata))
  lmz           <- lm(z~xdata-1)
  beta0         <- lmz$coef
  e             <- lmz$residual
  mu            <- gverse(lmz$fit)
  sigma         <- var(e)/((n-p)*dg_f(mu)^2)
  phi0          <- sum(mu*(1-mu)/sigma-1)/n
  
  start         <- c(beta0,phi0)  # initial value
  
  
  beta<- function(h, y, x)
  {
    p           <- ncol(x)
    hx          <- x%*%h[1: p]
    mu          <- 1/(1+exp(-hx))
    phi         <- h[p+1]
    mu          <- ifelse(mu<=0.0001,0.0001,mu)
    y           <- ifelse(y>0.995,0.995,y)
    y           <- ifelse(y<0.002,0.002,y)
    loglik      <- lgamma(phi)-lgamma(mu*phi)-lgamma(phi-mu*phi)+mu*phi*log(y)+(phi-mu*phi)*log(1-y)-log(y)-log(1-y)
    
    pscad=function(x){
      
      if (x <= lambda)
        y  = lambda*x
      else if(x <= lambda*gamma)
        y  = (lambda*gamma*x-0.5*(x^2+lambda^2))/(gamma-1)
      else
        y = lambda^2*(gamma^2-1)/(2*(gamma-1))
      y
    }
    
    scad=0
    for (l in 2:p){
      scad = scad+pscad(abs(h[l]))
    }
    
    -sum(loglik)+n*scad
    
    
  }
  
  betafit <- nlminb(start, beta, x = xdata, y = ydata)
  
}

#===================                choose tune parameter in simulation   ===========================
cv_f          <- function(xdata,ydata,xpre,ypre,Lambda,type){
  
  n_lam       <- length(Lambda)
  p           <- ncol(xdata)
  BETA        <- matrix(0,nr=p+1,nc=n_lam)
  cv_error    <- vector()
  for(l in 1:n_lam){
    if(type=='group'){
      fitscad  <- group_scad(xdata,ydata,lambda=Lambda[l],gamma=3.7)
    }
    if(type=='single'){
      fitscad  <- single_scad(xdata,ydata,lambda=Lambda[l],gamma=3.7)
    }
    beta_fit   <- fitscad$par
    BETA[,l]   <- beta_fit
    hx         <- xpre%*%beta_fit[1:p]
    mu         <- 1/(1+exp(-hx))
    cv_error[l]<- sum((ypre-mu)^2)
  }
  pos_l        <- which.min(cv_error)
  beta_fit     <- BETA[,pos_l]
  return(list(beta=beta_fit,lambda=Lambda[pos_l]))
}




#===================               CV in real data analysis            ==================
CV_R          <- function(xdata,ydata,Lambda,type){
  set.seed(1234)
  n           <- nrow(xdata)
  p           <- ncol(xdata)
  n_lam       <- length(Lambda)
  cv_error    <- matrix(0,nr=n_lam,nc=5)
  Indx        <- sample(n,n)
  xdata       <- xdata[Indx,]
  ydata       <- ydata[Indx]
  
  for(i in 1:5){
    ind          <- ((i-1)/5*n+1):(i/5*n) 
    xdata.train  <- xdata[-ind,]
    xdata.test   <- xdata[ind,]
    ydata.train  <- ydata[-ind]
    ydata.test   <- ydata[ind]
    for(l in 1:n_lam){
      if(type=='group'){
        fitscad  <- group_scad(xdata.train,ydata.train,lambda=Lambda[l],gamma=3.7)
      }
      if(type=='single'){
        fitscad  <- single_scad(xdata.train,ydata.train,lambda=Lambda[l],gamma=3.7)
      }
      beta_fit   <- fitscad$par
      
      hx         <- xdata.test%*%beta_fit[1:p]
      mu         <- 1/(1+exp(-hx))
      cv_error[l,i]<- sum((ydata.test-mu)^2)
    }
  }
  
  pos             <- which.min(rowMeans(cv_error))
  lambda          <- Lambda[pos]
  
  return(lambda)
}

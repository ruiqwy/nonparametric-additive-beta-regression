require(RCurl)
require(stringr) 
url  <- 'http://staff.pubhealth.ku.dk/~tag/Teaching/share/data/Bodyfat.csv'
temp <- getURL(url)
DAT  <- read.csv(text=temp)
View(DAT)
hist(DAT[,2]/100,prob=T,breaks=40,main="",xlabs="Percentage of body fat")
lines(density(DAT[,2]/100),col=2)
##
Args <- commandArgs()
loop <- Args[6]
loop <- as.numeric(loop)


library(MASS)
library(gamboostLSS)
library(gamlss)
library(stringr)
source('fun_1.R')
loop=loop+1
set.seed(1203*loop)
y    <- DAT[,2]/100
X    <- DAT[,-(1:2)]
X    <- X[-c(31,39,42,86),]
y    <- y[-c(31,39,42,86)]
n           <- nrow(X)
X           <- scale(X)
phi_X       <- matrix(apply(X,2,function(x) basis(x)),nr=n)                         ### convert to basis
phi_X       <- cbind(1,phi_X)
y           <- ifelse(y>0.995,0.995,y)
y           <- ifelse(y<0.002,0.002,y)
p           <- ncol(X)
indx        <- sample(n,2/3*n)
y.train     <- y[indx]
phi_X.train <- phi_X[indx,]
y.test      <- y[-indx]
phi_X.test  <- phi_X[-indx,]
X.train     <- X[indx,]
X.test      <- X[-indx,]
MSE         <- vector()
source('fun_1.R')
Lambda1           <- seq(30,120,by=7)
lam_group         <- CV_R(xdata=phi_X.train, ydata=y.train, Lambda1,type='group')
fit_group         <- group_scad(xbasis=phi_X.train,ydata=y.train,lambda=lam_group,gamma=3.7)

beta_group        <- fit_group$par
b_group           <- beta_group[2:(p*5+1)]
b_matgroup        <- matrix(b_group,nr=5)
pos_g             <- c(1,rep(colSums(abs(b_matgroup))>0.05,each=5),1)
beta_group0       <- beta_group*pos_g


MSE[1]            <- sum((y.test-gverse(phi_X.test%*%beta_group[-length(beta_group)]))^2)/(n-length(indx))
MSE[2]            <- sum((y.test-gverse(phi_X.test%*%beta_group0[-length(beta_group0)]))^2)/(n-length(indx))

#=========================                   linear model                    ===========

Lambda3           <- seq(10,50,by=4)
lam_X             <- CV_R(xdata=cbind(1,X.train), ydata=y.train,Lambda3,type='single')
fit_X             <- single_scad(xdata=cbind(1,X.train),ydata=y.train,lambda=lam_X,gamma=3.7)
beta_X            <- fit_X$par
b_X               <- beta_X[2:(p+1)]
beta_X0           <- beta_X*c(1,abs(b_X)>0.005,1)
MSE[3]            <- sum((y.test-gverse(cbind(1,X.test)%*%beta_X0[-length(beta_X0)]))^2)/(n-length(indx))
#MSE[4]            <- sum((y.test-gverse(cbind(1,X.test)%*%beta_X[-length(beta_X0)]))^2)/(n-length(indx))


#=========================                   boost model                     ===========
data2            <- data.frame(y=y,X=X)
fit_boost        <- gamboostLSS(formula=y~.,data=data2[indx,],families=BetaLSS())
ff1              <- cv(rep(1,length(indx)),type='kfold',B=5)
fcvr             <- cvrisk(fit_boost,folds=ff1,grid=make.grid(c(mu=100,phi=100), length.out = 10, min =20, log = TRUE,
                                                              dense_mu_grid = TRUE),trace=FALSE)

fit_boost        <- gamboostLSS(formula=y~.,data=data2[indx,],families=BetaLSS(),control = boost_control(mstop = mstop(fcvr)))

premu            <- predict(fit_boost,newdata=data2[-indx,-1])$mu
MSE[4]           <- sum((y.test-gverse(premu))^2)/(n-length(indx))

write.csv(MSE,paste0('//hpcserver-soe/HPCUserFile$/fkn/User/beta regression/beta regression/res/RES-real',loop,'.csv'))
write.csv(beta_group,paste0('//hpcserver-soe/HPCUserFile$/fkn/User/beta regression/beta regression/res/Bg-real',loop,'.csv'))
write.csv(beta_X,paste0('//hpcserver-soe/HPCUserFile$/fkn/User/beta regression/beta regression/res/Bx-real',loop,'.csv'))




loop    =1


library(MASS)
library(gamboostLSS)
library(gamlss)
library(stringr)
source('fun_1.R')


###### phi=10,60,120;n=300,500;p=15,30
###### compare group scad, linar model, boost model
### parmaters
p        <- ifelse(loop<=240,15,30)
phi      <- ifelse((loop-1)%%240+1<=80,10,ifelse((loop-1)%%240+1<=160,60,120))
n        <- ifelse(loop%%2==1,300,500)
rho      <- ifelse((loop-1)%%4<=1,0,0.5)

MSE      <- vector()
TP       <- vector()
FP       <- vector()
### 
sigma       <- matrix(0,p,p)  

for(i in 1:p){
  for(j in i:p){
    sigma[i,j] <- pho^abs(i-j)
    sigma[j,i] <- sigma[i,j]
  }
}
diag(sigma)<- 1

#========================                   generate data                     ====================

set.seed(loop*123)

X           <- mvrnorm(3*n,rep(0,p),Sigma = sigma)
phi_X       <- matrix(apply(X,2,function(x) basis(x)),nr=3*n)                         ### convert to basis
phi_X       <- cbind(1,phi_X)


f_1         <- 0.2*log(X[,1]^2+1)                    ### additive functions
f_2         <- 0.2*exp(-(X[,2]))
f_3         <- 0.2*X[,3]*(1-X[,3])
f_4         <- 0.5*sin(0.2*pi*X[,4])
f_5         <- 0.3*X[,5] 



mu          <- 1/(1+exp(-(f_1+f_2+f_3+f_4+f_5)))
beta_p      <- mu*phi
beta_q      <- (1-mu)*phi
y           <- rbeta(3*n,beta_p,beta_q)           ### generate y
y           <- ifelse(y>0.995,0.995,y)
y           <- ifelse(y<0.002,0.002,y)



#========================                  the group SCAD                     ==========

Lambda1           <- seq(30,100,by=5)
fit_group         <- cv_f(xdata=phi_X[1:n,], ydata=y[1:n], xpre=phi_X[(n+1):(2*n),],
                          ypre=y[(n+1):(2*n)],Lambda1,type='group')
beta_group        <- fit_group$beta
b_group           <- beta_group[2:(p*5+1)]
b_matgroup        <- matrix(b_group,nr=5)
pos_g             <- c(1,rep(colSums(abs(b_matgroup))>5*10^(-2),each=5),1)
beta_group0       <- beta_group*pos_g

MSE[1]            <- sum((y[(2*n+1):(3*n)]-gverse(phi_X[(2*n+1):(3*n),]%*%beta_group[-length(beta_group)]))^2)/n
MSE[2]            <- sum((y[(2*n+1):(3*n)]-gverse(phi_X[(2*n+1):(3*n),]%*%beta_group0[-length(beta_group0)]))^2)/n
TP[1]             <- sum(colSums(abs(b_matgroup))[1:5]>5*10^(-2))
FP[1]             <- sum(colSums(abs(b_matgroup))>5*10^(-2))-sum(colSums(abs(b_matgroup))[1:5]>5*10^(-2))
TP[2]             <- TP[1]
FP[2]             <- FP[1]

#=========================                   linear model                    ===========

Lambda3           <- seq(5,30,by=4)
fit_X             <- cv_f(xdata=cbind(1,X[1:n,]), ydata=y[1:n], xpre=cbind(1,X[(n+1):(2*n),]),
                          ypre=y[(n+1):(2*n)],Lambda3,type='single')
beta_X            <- fit_X$beta
b_X               <- beta_X[2:(p+1)]
beta_X0           <- beta_X*c(1,abs(b_X)>0.005,1)
MSE[3]            <- sum((y[(2*n+1):(3*n)]-gverse(cbind(1,X[(2*n+1):(3*n),])%*%beta_X0[-length(beta_X0)]))^2)/n
TP[3]             <- sum(abs(b_X)[1:5]>0.005)
FP[3]             <- sum(abs(b_X)>0.005)-sum(abs(b_X)[1:5]>0.005)


#=========================                   boost model                     ===========

data2            <- data.frame(y=y,X=X)
fit_boost        <- gamboostLSS(formula=y~.,data=data2[1:n,],families=BetaLSS())
ff1              <- cv(rep(1,n),type='kfold',B=5)
fcvr             <- cvrisk(fit_boost,folds=ff1,grid=make.grid(c(mu=100,phi=100), length.out = 10, min =20, log = TRUE,
                                                              dense_mu_grid = TRUE),trace=FALSE)

fit_boost        <- gamboostLSS(formula=y~.,data=data2[1:n,],families=BetaLSS(),control = boost_control(mstop = mstop(fcvr)))

premu            <- predict(fit_boost,newdata=data2[(2*n+1):(3*n),-1])$mu
coefmu           <- coef(fit_boost)$mu
MSE[4]           <- sum((y[(2*n+1):(3*n)]-gverse(premu))^2)/n

pos_1            <- regexpr('\\.',names(coefmu))+1
pos_2            <- regexpr(',',names(coefmu))-1
Sigv             <- unique(as.numeric(str_sub(names(coefmu),pos_1,pos_2)))
TP[4]            <- sum(Sigv<=5)
FP[4]            <- length(Sigv)-sum(Sigv<=5)

RES              <- rbind(MSE,TP,FP)
